# Credits

To __marcelveldt__ for giving me a base: https://github.com/kodi-community-addons/resource.uisounds.titan.modern/tree/master

#About

This is a UI audio resource designed to sound like windows 8.1, combined with amber gives it that __2013__ feeling
